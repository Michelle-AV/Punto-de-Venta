package basededatos;
import java.sql.*;
import javax.swing.*;
/**@author LGRR */

public class CategoriasBD {
    
    ResultSet rs;
    Statement st;
    ConexionAbarrotes c=new ConexionAbarrotes();
    Connection conexion;
    
    public CategoriasBD(){
        conexion=c.retornoConexion();
    }
    
    //Metodo para crear un array con las categorias
    public String [] categorias(){
        String sql="select des_cat from categorias;";
        String []categorias=new String[1];
        try{
           st=conexion.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,ResultSet.CONCUR_READ_ONLY);
           rs=st.executeQuery(sql);
           rs.last();//Obtiene la ultima tupla del select
           int filas=rs.getRow();//Obtiene el numero de la ultima fila
           rs.beforeFirst();
           categorias=new String[filas];//Ahora el array 'x' tiene de tamaño la variable Filas
           filas=0;
           while(rs.next()){//Va a terminar hasta que no hayan mas tuplas
               categorias[filas]=rs.getString("des_cat");//Va guardando en el arreglo las descripciones de categorias
               filas++;//Incrementa el iterador del array
           }  
        }catch(Exception e){
           JOptionPane.showMessageDialog(null,e.getMessage() );
           System.out.println(e.getMessage());
        }finally{
            try {
                st.close();
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(null,ex.getMessage() );
            }
        }
        return categorias;//Retorna el array de tipo String con las 
    }
    
    
    //METODO PARA INSERTAR LA SENTENCIA QUE SE LE ENVIE
    public boolean insertarCategoria(int id_cat, String des_cat){
        String sql="insert into categorias values("+id_cat+",'"+des_cat+"');";
        boolean respuesta=true;
        try{
            st=conexion.createStatement();
            respuesta=st.execute(sql); //Si todo fue bien, retorna false
            System.out.println(respuesta);
        }catch(Exception e){
            JOptionPane.showMessageDialog(null,e.getMessage() );
            System.out.println(e.getMessage());
        }finally{
            try{
                st.close();
            }catch(Exception ex){
                JOptionPane.showMessageDialog(null,ex.getMessage() );
                System.out.println(ex.getMessage());
            }
        }
        return !respuesta;
    }
    
    public int retornoIdeCat(){
        int id_cat=1;
        String sql="select id_cat from categorias order by id_cat DESC limit 1;";
        try{
            st=conexion.createStatement();
            rs=st.executeQuery(sql);
            rs.next();
            int id_cat2=rs.getInt("id_cat");
            id_cat=id_cat2+1;
        }catch(Exception ex){
            System.out.println(ex.getMessage());
        }finally{
            try {
                st.close();
            } catch (SQLException ex) {
                System.out.println(ex.getMessage() );
            }
        }
        return id_cat;
    }
    
}
