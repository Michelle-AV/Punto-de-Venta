package basededatos;
import javax.swing.*;
import java.sql.*;

/* @author LGRR */
public class ComprasDB {
    
    ResultSet rs;
    Statement st;
    
    ConexionAbarrotes c=new ConexionAbarrotes();
    Connection conexion;
    
    public ComprasDB(){
        conexion=c.retornoConexion();
    }
    
    public int numCompra(){
        String sql="select id_compra from compras order by id_compra DESC limit 1;";
        int id_compra=1;
        try{
            st=conexion.createStatement();
            rs=st.executeQuery(sql);
            rs.next();
            int id_compra2=rs.getInt("id_compra");
            id_compra=id_compra2+1;
        }catch(Exception ex){
            System.out.println(ex.getMessage());
        }finally{
            try {
                st.close();
            } catch (SQLException ex) {
                System.out.println(ex.getMessage() );
            }
        }
        
        return id_compra;
    }
    
    
    //METODO PARA INSERTAR COMPRA
    public boolean insertarCompra(int id_compra, int  total_com, int anio, int mes, int dia ){
        String sql="Insert into compras(id_compra, total_com, fecha_com) values("+id_compra+","+total_com+",'"+anio+"-"+mes+"-"+dia+"');";
        boolean respuesta=true;
        try{
            st=conexion.createStatement();
            respuesta=st.execute(sql); //Si todo fue bien, retorna false
            System.out.println(respuesta);
        }catch(Exception e){
            JOptionPane.showMessageDialog(null,e.getMessage() );
            System.out.println(e.getMessage());
        }finally{
            try{
                st.close();
            }catch(Exception ex){
                JOptionPane.showMessageDialog(null,ex.getMessage() );
                System.out.println(ex.getMessage());
            }
        }
        return !respuesta;
    }
    
    //Metodo para obtener los ides de las compras, para poder llenar un jcombobox
    public String [] ides_compras(){
        String sql="select id_compra from compras;";
        String []ides=new String[1];
        try{
           st=conexion.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,ResultSet.CONCUR_READ_ONLY);
           rs=st.executeQuery(sql);
           rs.last();//Obtiene la ultima tupla del select
           int filas=rs.getRow();//Obtiene el numero de la ultima fila
           rs.beforeFirst();
           ides=new String[filas];//Ahora el array 'x' tiene de tamaño la variable Filas
           filas=0;
           while(rs.next()){//Va a terminar hasta que no hayan mas tuplas
               ides[filas]=rs.getString("id_compra");//Va guardando en el arreglo los codigos de barra 
               filas++;//Incrementa el iterador del array
           }  
        }catch(Exception e){
           JOptionPane.showMessageDialog(null,e.getMessage() );
           System.out.println(e.getMessage());
        }finally{
            try {
                st.close();
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(null,ex.getMessage() );
            }
        }
        return ides;//Retorna el array de tipo String con las 
    }
    
    public boolean insertarDCompra(int id_compra, int cns, int cod_barra, int precio_com, int cantidad){
        String sql="Insert into detallecompras(id_compra, cns, cod_barra, precio_com, cantidad) values("+id_compra+","+cns+","+cod_barra+","+precio_com+","+cantidad+");";
        System.out.println(sql);
        boolean respuesta=true;
        try{
            st=conexion.createStatement();
            respuesta=st.execute(sql); //Si todo fue bien, retorna false
            System.out.println(respuesta);
        }catch(Exception e){
            JOptionPane.showMessageDialog(null,e.getMessage() );
            System.out.println(e.getMessage());
        }finally{
            try{
                st.close();
            }catch(Exception ex){
                JOptionPane.showMessageDialog(null,ex.getMessage() );
                System.out.println(ex.getMessage());
            }
        }
        return !respuesta;    
    }
    
    public int cnsDCompra(int id_compra){
        int cns=1;
        String sql="select cns from detallecompras where id_compra="+id_compra+" order by cns DESC limit 1;";
        
        try{
           st=conexion.createStatement();
           rs=st.executeQuery(sql);
           while(rs.next()){
              int cns2=rs.getInt("cns"); 
              cns=cns2+1;      
           }       
        }catch(Exception e){
            System.out.println(e.getMessage());
        }finally{
            try {
                st.close();
            } catch (SQLException ex) {
                System.out.println(ex.getMessage() );
            }
        }
        
        return cns;
    }
    
}
