package basededatos;
import java.sql.*;
import javax.swing.*;

public class ProductosBD {
    
    ResultSet rs;
    Statement st;
    ConexionAbarrotes c=new ConexionAbarrotes();
    Connection conexion;
    
    public ProductosBD() {
        conexion=c.retornoConexion();
    }
    
    public boolean insertarProducto(int cod_barra, int precio_venta,String des_producto, int id_cat){
        String sql="Insert into productos(cod_barra, precio_venta, des_producto, id_cat) values("+cod_barra+","+precio_venta+",'"+des_producto+"',"+id_cat+");";
        boolean respuesta=true;
        try{
            st=conexion.createStatement();
            respuesta=st.execute(sql); //Si todo fue bien, retorna false
            System.out.println(respuesta);
        }catch(Exception e){
            JOptionPane.showMessageDialog(null,e.getMessage() );
            System.out.println(e.getMessage());
        }finally{
            try{
                st.close();
            }catch(Exception ex){
                JOptionPane.showMessageDialog(null,ex.getMessage() );
                System.out.println(ex.getMessage());
            }
        }
        return !respuesta;
    }
    
    //Metodo para crear un array con las codigos de barra de los productos
    public String [] codigosB(){
        String sql="select cod_barra from productos;";
        String []codigos=new String[1];
        try{
           st=conexion.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,ResultSet.CONCUR_READ_ONLY);
           rs=st.executeQuery(sql);
           rs.last();//Obtiene la ultima tupla del select
           int filas=rs.getRow();//Obtiene el numero de la ultima fila
           rs.beforeFirst();
           codigos=new String[filas];//Ahora el array 'x' tiene de tamaño la variable Filas
           filas=0;
           while(rs.next()){//Va a terminar hasta que no hayan mas tuplas
               codigos[filas]=rs.getString("cod_barra");//Va guardando en el arreglo los codigos de barra 
               filas++;//Incrementa el iterador del array
           }  
        }catch(Exception e){
           JOptionPane.showMessageDialog(null,e.getMessage() );
           System.out.println(e.getMessage());
        }finally{
            try {
                st.close();
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(null,ex.getMessage() );
            }
        }
        return codigos;//Retorna el array de tipo String con las 
    }
    
    //Metodo para crear un array con las codigos de barra de los productos
    public String [] codigosBarraConStock(){
        String sql="select cod_barra from productos where stock!=0;";
        String []codigos=new String[1];
        try{
           st=conexion.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,ResultSet.CONCUR_READ_ONLY);
           rs=st.executeQuery(sql);
           rs.last();//Obtiene la ultima tupla del select
           int filas=rs.getRow();//Obtiene el numero de la ultima fila
           rs.beforeFirst();
           codigos=new String[filas];//Ahora el array 'x' tiene de tamaño la variable Filas
           filas=0;
           while(rs.next()){//Va a terminar hasta que no hayan mas tuplas
               codigos[filas]=rs.getString("cod_barra");//Va guardando en el arreglo los codigos de barra 
               filas++;//Incrementa el iterador del array
           }  
        }catch(Exception e){
           JOptionPane.showMessageDialog(null,e.getMessage() );
           System.out.println(e.getMessage());
        }finally{
            try {
                st.close();
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(null,ex.getMessage() );
            }
        }
        return codigos;//Retorna el array de tipo String con las 
    }
    
    public int seleccionDesCat(String des_cat){
        int id_cat=0;
        String sql="select id_cat from categorias where des_cat='"+des_cat+"';";
       try{
            st=conexion.createStatement();
            rs=st.executeQuery(sql);
            rs.next();
            id_cat=rs.getInt("id_cat");
       }catch(Exception ex){
           System.out.println(ex);
       }finally{
           try{
               st.close();
           }catch(SQLException r){
               System.out.println(r.getMessage());
           }
       }
       
       return id_cat;
    }
 
    public int eliminarProducto(String cod_barra){
         String sql="delete from productos where cod_barra="+cod_barra+";";
        int ress=0;
        try{
            st=conexion.createStatement();
            ress=st.executeUpdate(sql);
            System.out.println(ress);
        }catch(SQLException u){
            System.out.println(u.getMessage());
        }finally{
            try{
                st.close();
            }catch(SQLException a){
                System.out.println(a.getMessage());
            }
        } 
        return ress;
    }
    
    //Metodo que retorna la descripcion de un producto dado un codigo de barras 
    public String desProducto(int code_barra){
        String des_producto=null;
        String sql="select des_producto From productos where cod_barra="+code_barra+";";
         try{
            st=conexion.createStatement();
            rs=st.executeQuery(sql);
            rs.next();
            des_producto=rs.getString("des_producto");
        }catch(Exception ec){
            System.out.println(ec.getMessage());
        }finally{
            try{
              st.close();
            }catch(SQLException ex){
                System.out.println(ex.getMessage());
            }
        }
        return des_producto;
    }
    
    //Metodo que retorna el precio de venta de un producto dado un codigo de barras 
    public String PrecioV(int code_barra){
        String precio=null;
        String sql="select precio_venta From productos where cod_barra="+code_barra+";";
         try{
            st=conexion.createStatement();
            rs=st.executeQuery(sql);
            rs.next();
            precio=rs.getString("precio_venta");
        }catch(Exception ec){
            System.out.println(ec.getMessage());
        }finally{
            try{
              st.close();
            }catch(SQLException ex){
                System.out.println(ex.getMessage());
            }
        }
        return precio;
    }
    
}
