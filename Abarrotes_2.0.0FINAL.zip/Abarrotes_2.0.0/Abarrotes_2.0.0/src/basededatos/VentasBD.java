package basededatos;
import java.sql.*;
import javax.swing.*;

/* @author LGRR */
public class VentasBD {
    
    ConexionAbarrotes c=new ConexionAbarrotes();
    Connection conexion;
    ResultSet rs;
    Statement st;
    
    
    public VentasBD(){
        conexion=c.retornoConexion();
    }
    
       
    //METODO PARA INSERTAR VENTA
    public boolean insertarVenta(int id_venta, String fecha, int monto, String metodo_pago ){
        String sql="Insert into ventas(id_venta,fecha_venta,monto,metodo_pago) values("+id_venta+",'"+fecha+"',"+monto+", '"+metodo_pago+"');";
        boolean respuesta=true;
        try{
            st=conexion.createStatement();
            respuesta=st.execute(sql); //Si todo fue bien, retorna false
            System.out.println(respuesta);
        }catch(Exception e){
            JOptionPane.showMessageDialog(null,e.getMessage() );
            System.out.println(e.getMessage());
        }finally{
            try{
                st.close();
            }catch(Exception ex){
                JOptionPane.showMessageDialog(null,ex.getMessage() );
                System.out.println(ex.getMessage());
            }
        }
        return !respuesta;
    }
    
    //METODO PARA INSERTAR  DETALLE DE VENTA
    public boolean insertarDVenta(String cod_barra, int id_venta,int cnsdv, String montoDV,String  cantidad_v,  String des_venta ){
         String sql="insert into detalleventas values("+cod_barra+","+id_venta+","+cnsdv+","+montoDV+","+cantidad_v+",'"+des_venta+"');";
        boolean respuesta=true;
        try{
            st=conexion.createStatement();
            respuesta=st.execute(sql); //Si todo fue bien, retorna false
            System.out.println(respuesta);
        }catch(Exception e){
            JOptionPane.showMessageDialog(null,e.getMessage() );
            System.out.println(e.getMessage());
        }finally{
            try{
                st.close();
            }catch(Exception ex){
                JOptionPane.showMessageDialog(null,ex.getMessage() );
                System.out.println(ex.getMessage());
            }
        }
        return !respuesta;
    }
    
    public int cnsDVentas(int id_venta){
        String sql="select cns from detalleventas where id_venta="+id_venta+" order by cns DESC limit 1;";
        int cns=1;
        try{
            st=conexion.createStatement();
            rs=st.executeQuery(sql);
            rs.next();
            int cnsdv2=rs.getInt("cns");
            System.out.println("cns dv:"+cnsdv2);
            cns=cnsdv2+1;
        }catch(Exception ex){
            System.out.println(ex.getMessage());
        }finally{
            try {
                st.close();
            } catch (SQLException ex) {
                System.out.println(ex.getMessage() );
            }
        }
        return cns;
    }
    
    public int numVentaIncre(){
        String sql="select id_venta from ventas order by id_venta DESC limit 1;";
        int id_venta=1;
        try{
            st=conexion.createStatement();
            rs=st.executeQuery(sql);
            rs.next();
            int id_venta2=rs.getInt("id_venta");
            id_venta=id_venta2+1;
        }catch(Exception ex){
            System.out.println(ex.getMessage());
        }finally{
            try {
                st.close();
            } catch (SQLException ex) {
                System.out.println(ex.getMessage());
            }
        }
        return id_venta;
    }
    
    
}
