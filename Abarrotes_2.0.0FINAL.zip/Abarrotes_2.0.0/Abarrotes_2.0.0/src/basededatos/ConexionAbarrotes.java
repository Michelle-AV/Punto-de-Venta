package basededatos;
import java.sql.*;
import javax.swing.*;
/* * @author LGRR
 */
public class ConexionAbarrotes {
    Connection conexion=null;
    Statement st;
    ResultSet rs;
    String driver="org.postgresql.Driver";
    String user="postgres";
    String bd="jdbc:postgresql://localhost:5432/abarrotes";
    String password="postgres";
   
    public ConexionAbarrotes(){
        try{
            Class.forName(driver);
            conexion=DriverManager.getConnection(bd, user, password);
            if(conexion!=null){
                System.out.println("Conexion ok");
            }else{
                System.out.println("No se logro la conexion");
            }
        }catch(SQLException ex){
            System.out.println(ex.getMessage());   
        }catch(ClassNotFoundException e){
            System.out.println(e.getMessage());
        }  
    }
    
    public Connection retornoConexion(){
        return conexion;
    }    
    
    public ResultSet rsMethod(String sentencia){//Metodo que recibe una sentencia sql y retorna un Resultset
        try{
            st=conexion.createStatement();
            rs=st.executeQuery(sentencia);
        }catch(SQLException e){
            System.out.println(e.getMessage());
        }
        return rs;
    }
}
