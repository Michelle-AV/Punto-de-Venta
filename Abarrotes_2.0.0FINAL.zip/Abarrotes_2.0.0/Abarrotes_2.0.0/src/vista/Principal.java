package vista;
import javax.swing.*;
import java.sql.*;
import basededatos.*;
import java.time.LocalDate;
import java.util.ArrayList;
import javax.swing.table.DefaultTableModel;



/*@author LGRR */

public class Principal extends javax.swing.JFrame {
    ConexionAbarrotes c;
    ProductosBD productos;
    VentasBD ventas;
    ResultSet rs;
    Statement st;
    Connection conexion;
    int cnsdv=1;//Variable cns de detalleventa
    int cambio=0;
    int calculoTotal=0;
    String metodo_pago=null;
    DefaultTableModel modeloT=new DefaultTableModel();
    DefaultTableModel modeloComprobante=new DefaultTableModel();
    LocalDate datehoy=LocalDate.now();
    
    
    public Principal() {
        initComponents();
        this.setTitle("ABARROTES-Punto de venta");
        //this.setLocationRelativeTo(null);
        this.setResizable(false);
        c=new ConexionAbarrotes();
        productos=new ProductosBD();
        ventas=new VentasBD();
        conexion=c.retornoConexion();
        llenar_ComboCodigos();
        incrementaNoVenta();
        ModeloTabla();
        //Estableciendo la fecha
        jlabelFecha.setText(datehoy.toString());
        txtIngreso.setVisible(false);
        jLabel4.setVisible(false);
        
        jPanel7.setVisible(false);

        LlenarVentas();
        jPanel2.setVisible(false);

        
        
        this.setResizable(false);
        this.setLocationRelativeTo(null);
    }
    
    //Metodo para crear el modelo de la tabla
    public void ModeloTabla(){
        String columnas[]={"DESCRIPCION","CODIGO BARRAS","PRECIO", "CANTIDAD", "SUBTOTAL"};
        modeloT.setColumnIdentifiers(columnas);
        jTable1.setModel(modeloT);
    }
    
    public void LlenarVentas(){
        ResultSet rs=c.rsMethod("Select*from ventas order by id_venta;");
        DefaultTableModel modeloVenta=new DefaultTableModel();
        modeloVenta.setColumnIdentifiers(new Object[]{"Id. venta","Fecha","Total","Metodo"});
        try{
            while(rs.next()){
               modeloVenta.addRow(new Object[]{rs.getString("id_venta"),rs.getString("fecha_venta"),rs.getString("monto"),rs.getString("metodo_pago")});
            }
            jTable2.setModel(modeloVenta);
            jTable2.setEnabled(false);//Para que no se puedan editar los datos en el componente
        }catch(Exception e){
            JOptionPane.showMessageDialog(null,e.getMessage() );
        } 
    }
   
    public void Comprobante( int id_venta, int monto, int cambio, int importe){
        
        String colm[]={"DESCRIPCION", "CODIGO","CANTIDAD", "MONTO"};
        modeloComprobante.setColumnIdentifiers(colm);
        String sql="select des_venta, cod_barra, cantidad_v, monto from detalleventas where id_venta="+id_venta+";";
        try{
            st=conexion.createStatement();
            rs=st.executeQuery(sql);
            while(rs.next()){
                String dat[]=new String[4];
                dat[0]=rs.getString("des_venta");
                dat[1]=rs.getString("cod_barra");
                dat[2]=rs.getString("cantidad_v");
                dat[3]=rs.getString("monto");
                modeloComprobante.addRow(dat);
            }
        }catch(Exception f){
            System.out.println(f.getMessage());
        }finally{
            try{
                st.close();
            }catch(SQLException n){
                System.out.println(n.getMessage());
            }
        }
        
        jTable3.setModel(modeloComprobante);
        jPanel2.setVisible(true);
        jTextField2.setText(monto+"");
        jTextField3.setText(cambio+"");
        jTextField4.setText(importe+"");
    }
    
    
    //Metodo para llenar el JCombobox de codigos de barra
    public void llenar_ComboCodigos(){
        CBCODIGOSVENTA.removeAllItems();
        CBCODIGOSVENTA.addItem("CODIGOS");
        String []codigosCB=productos.codigosBarraConStock();
        for(String i:codigosCB){
            CBCODIGOSVENTA.addItem(i);//Se agregan en el combobox
        } 
    }
    
    public void incrementaNoVenta(){
        int id_venta=ventas.numVentaIncre();
        txtNoVenta.setText( Integer.toString(id_venta));
    }
    
    
    public void cnsDVentas(int id_venta){
        
        cnsdv=ventas.cnsDVentas(id_venta);
    }
    
    public void limpiarTabla(){
        DefaultTableModel modelo2 = (DefaultTableModel) jTable1.getModel();
        while(modelo2.getRowCount()>0){
            modelo2.removeRow(0);
        }
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        grupoJB = new javax.swing.ButtonGroup();
        jPanel2 = new javax.swing.JPanel();
        jScrollPane3 = new javax.swing.JScrollPane();
        jTable3 = new javax.swing.JTable();
        jButton4 = new javax.swing.JButton();
        jTextField2 = new javax.swing.JTextField();
        jTextField3 = new javax.swing.JTextField();
        jTextField4 = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        jPanel7 = new javax.swing.JPanel();
        jButton3 = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        bt_Productos = new javax.swing.JButton();
        btCompras = new javax.swing.JButton();
        BTVENTAS = new javax.swing.JButton();
        jPanel1 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jPanel5 = new javax.swing.JPanel();
        jLabel11 = new javax.swing.JLabel();
        txtNoVenta = new javax.swing.JTextField();
        jLabel12 = new javax.swing.JLabel();
        jlabelFecha = new javax.swing.JLabel();
        jTextField1 = new javax.swing.JTextField();
        jPanel6 = new javax.swing.JPanel();
        VENTA = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        txtIngreso = new javax.swing.JTextField();
        btPagar = new javax.swing.JButton();
        jRadioButton1 = new javax.swing.JRadioButton();
        jRadioButton2 = new javax.swing.JRadioButton();
        txt_TotalVenta = new javax.swing.JTextField();
        txt_CambioVenta = new javax.swing.JTextField();
        CBCODIGOSVENTA = new javax.swing.JComboBox<>();
        CBCANTIDADPRODUCTOS = new javax.swing.JComboBox<>();
        jButton2 = new javax.swing.JButton();
        jButton5 = new javax.swing.JButton();
        jScrollPane2 = new javax.swing.JScrollPane();
        jTable2 = new javax.swing.JTable();
        jLabel6 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jTable3.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane3.setViewportView(jTable3);

        jPanel2.add(jScrollPane3, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 230, 500, 180));

        jButton4.setText("CONFIRMAR");
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });
        jPanel2.add(jButton4, new org.netbeans.lib.awtextra.AbsoluteConstraints(440, 490, -1, -1));
        jPanel2.add(jTextField2, new org.netbeans.lib.awtextra.AbsoluteConstraints(470, 450, 70, -1));
        jPanel2.add(jTextField3, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 482, 80, 30));
        jPanel2.add(jTextField4, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 482, 80, 30));

        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Iconos/C (1).png"))); // NOI18N
        jPanel2.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, -1));

        getContentPane().add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(740, 170, 570, 540));

        jPanel7.setBackground(new java.awt.Color(61, 56, 52));
        jPanel7.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jButton3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Iconos/AE.png"))); // NOI18N
        jButton3.setBorder(null);
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });
        jPanel7.add(jButton3, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 560, 60, 50));

        jLabel1.setFont(new java.awt.Font("Microsoft JhengHei", 1, 12)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("Reportes");
        jPanel7.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 410, 70, 20));

        jLabel5.setBackground(new java.awt.Color(255, 255, 255));
        jLabel5.setFont(new java.awt.Font("Microsoft JhengHei", 1, 12)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(255, 255, 255));
        jLabel5.setText("Categorías");
        jPanel7.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 190, 70, 30));

        jLabel7.setFont(new java.awt.Font("Microsoft JhengHei", 1, 12)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(255, 255, 255));
        jLabel7.setText("Compras");
        jPanel7.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 300, 70, 30));

        jLabel8.setBackground(new java.awt.Color(255, 255, 255));
        jLabel8.setFont(new java.awt.Font("Microsoft JhengHei", 1, 12)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(255, 255, 255));
        jLabel8.setText("Productos");
        jPanel7.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 90, 70, 30));

        jButton1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Iconos/AF.png"))); // NOI18N
        jButton1.setBorder(null);
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        jPanel7.add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 130, 60, -1));

        bt_Productos.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Iconos/AB.png"))); // NOI18N
        bt_Productos.setBorder(null);
        bt_Productos.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bt_ProductosActionPerformed(evt);
            }
        });
        jPanel7.add(bt_Productos, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 20, -1, 70));

        btCompras.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Iconos/AD.png"))); // NOI18N
        btCompras.setBorder(null);
        btCompras.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btComprasActionPerformed(evt);
            }
        });
        jPanel7.add(btCompras, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 230, 80, 70));

        BTVENTAS.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Iconos/AH.png"))); // NOI18N
        BTVENTAS.setBorder(null);
        BTVENTAS.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BTVENTASActionPerformed(evt);
            }
        });
        jPanel7.add(BTVENTAS, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 340, 60, -1));

        getContentPane().add(jPanel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(27, 90, 100, 620));

        jPanel1.setBackground(new java.awt.Color(255, 255, 153));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jTable1.setBackground(new java.awt.Color(255, 255, 255));
        jTable1.setFont(new java.awt.Font("Segoe UI Semibold", 0, 14)); // NOI18N
        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane1.setViewportView(jTable1);

        jPanel1.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 170, 850, 320));

        jPanel5.setBackground(new java.awt.Color(204, 204, 204));
        jPanel5.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel11.setFont(new java.awt.Font("Microsoft JhengHei", 1, 12)); // NOI18N
        jLabel11.setText("Numero de venta:");
        jPanel5.add(jLabel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 20, -1, 20));
        jPanel5.add(txtNoVenta, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 20, 80, -1));

        jLabel12.setFont(new java.awt.Font("Microsoft JhengHei", 1, 12)); // NOI18N
        jLabel12.setText("Fecha:");
        jPanel5.add(jLabel12, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 70, -1, -1));

        jlabelFecha.setBackground(new java.awt.Color(76, 59, 59));
        jlabelFecha.setFont(new java.awt.Font("Segoe UI Semibold", 0, 18)); // NOI18N
        jPanel5.add(jlabelFecha, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 70, 110, 30));
        jPanel5.add(jTextField1, new org.netbeans.lib.awtextra.AbsoluteConstraints(83, 70, 140, -1));

        jPanel1.add(jPanel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 580, 390, 110));

        jPanel6.setBackground(new java.awt.Color(133, 81, 81));
        jPanel6.setForeground(new java.awt.Color(255, 255, 255));
        jPanel6.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        VENTA.setFont(new java.awt.Font("Segoe UI Symbol", 1, 12)); // NOI18N
        VENTA.setForeground(new java.awt.Color(255, 255, 255));
        VENTA.setText("VENTA");
        jPanel6.add(VENTA, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 0, -1, -1));

        jPanel1.add(jPanel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 560, 390, 20));

        jLabel4.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(86, 53, 53));
        jLabel4.setText("IMPORTE:");
        jPanel1.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(1100, 120, 100, 30));
        jPanel1.add(txtIngreso, new org.netbeans.lib.awtextra.AbsoluteConstraints(1200, 120, 100, 30));

        btPagar.setText("PAGAR");
        btPagar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btPagarActionPerformed(evt);
            }
        });
        jPanel1.add(btPagar, new org.netbeans.lib.awtextra.AbsoluteConstraints(800, 510, 90, 30));

        grupoJB.add(jRadioButton1);
        jRadioButton1.setText("EFECTIVO");
        jRadioButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jRadioButton1ActionPerformed(evt);
            }
        });
        jPanel1.add(jRadioButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(750, 120, -1, -1));

        grupoJB.add(jRadioButton2);
        jRadioButton2.setText("TARJETA");
        jRadioButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jRadioButton2ActionPerformed(evt);
            }
        });
        jPanel1.add(jRadioButton2, new org.netbeans.lib.awtextra.AbsoluteConstraints(840, 120, -1, -1));

        txt_TotalVenta.setBackground(new java.awt.Color(255, 255, 255));
        txt_TotalVenta.setFont(new java.awt.Font("Segoe UI Semibold", 0, 22)); // NOI18N
        txt_TotalVenta.setForeground(new java.awt.Color(87, 65, 65));
        txt_TotalVenta.setText("0");
        txt_TotalVenta.setBorder(null);
        jPanel1.add(txt_TotalVenta, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 510, 150, 30));

        txt_CambioVenta.setBackground(new java.awt.Color(255, 255, 255));
        txt_CambioVenta.setFont(new java.awt.Font("Segoe UI Semibold", 0, 22)); // NOI18N
        txt_CambioVenta.setForeground(new java.awt.Color(92, 61, 61));
        txt_CambioVenta.setText("$0");
        txt_CambioVenta.setBorder(null);
        txt_CambioVenta.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_CambioVentaActionPerformed(evt);
            }
        });
        jPanel1.add(txt_CambioVenta, new org.netbeans.lib.awtextra.AbsoluteConstraints(460, 510, 130, 30));

        CBCODIGOSVENTA.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        jPanel1.add(CBCODIGOSVENTA, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 120, 180, -1));

        CBCANTIDADPRODUCTOS.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12" }));
        CBCANTIDADPRODUCTOS.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CBCANTIDADPRODUCTOSActionPerformed(evt);
            }
        });
        jPanel1.add(CBCANTIDADPRODUCTOS, new org.netbeans.lib.awtextra.AbsoluteConstraints(560, 120, 80, -1));

        jButton2.setText("Actualizar codigos");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton2, new org.netbeans.lib.awtextra.AbsoluteConstraints(1170, 40, 140, -1));

        jButton5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Iconos/B.png"))); // NOI18N
        jButton5.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(183, 156, 156)));
        jButton5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton5ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton5, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 30, -1, -1));

        jTable2.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane2.setViewportView(jTable2);

        jPanel1.add(jScrollPane2, new org.netbeans.lib.awtextra.AbsoluteConstraints(460, 561, 440, 130));

        jLabel6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Iconos/Principal.png"))); // NOI18N
        jPanel1.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, -1));

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1350, 730));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    
    private void bt_ProductosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bt_ProductosActionPerformed
        //TODO add your handling code here:
        AltaProductos altaP=new AltaProductos();
        altaP.setVisible(true);
    }//GEN-LAST:event_bt_ProductosActionPerformed

    private void BTVENTASActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BTVENTASActionPerformed
        // TODO add your handling code here:
        Reportes re=new Reportes();
        re.setVisible(true);
    }//GEN-LAST:event_BTVENTASActionPerformed

    private void btPagarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btPagarActionPerformed
        
        //primero se guarda la venta
        int id_venta=Integer.parseInt(txtNoVenta.getText());
        String fecha=datehoy.toString();
        int monto=Integer.parseInt(txt_TotalVenta.getText());
        
        //La variable metodo_pago ya está creada
        boolean resultado;
        if(monto==0||metodo_pago==null){
            JOptionPane.showMessageDialog(null,"No se pudo guardar la venta");
        }else{
            resultado=ventas.insertarVenta(id_venta,fecha, monto, metodo_pago);
            JOptionPane.showMessageDialog(null,"Venta guardada con exito");
            grupoJB.clearSelection();            
            LlenarVentas();
        }     
        
        //Se guardan los detalles de la venta
        //Para tener el primero cns, mandamos a llamar el metodo 
         cnsDVentas(id_venta);
        //Para ir guardando los datos, iremos haciendo un recorrido en el jtable
        for(int i=0;i<jTable1.getRowCount();i++){
            String cod_barra=jTable1.getValueAt(i,1).toString();
            String montoDV=jTable1.getValueAt(i,4).toString();
            String cantidad_v=jTable1.getValueAt(i,3).toString();
            String des_venta=jTable1.getValueAt(i,0).toString();
            resultado=ventas.insertarDVenta(cod_barra, id_venta, cnsdv, montoDV, cantidad_v, des_venta);
            cnsDVentas(id_venta);//Se incrementa el cns
        }   
        
        //Limpiando la tabla 
        limpiarTabla();
        txt_TotalVenta.setText("0");
        
        //Calculo del cambio
        if(metodo_pago=="EFECTIVO"){
            int cambio=Integer.parseInt(txtIngreso.getText())-monto;
            int ingreso=Integer.parseInt(txtIngreso.getText());
            txt_CambioVenta.setText("$"+cambio);
            JOptionPane.showMessageDialog(null,"El cambio es de $"+cambio);     
            txt_CambioVenta.setText("$0");
            txtIngreso.setText("");
            txtIngreso.setVisible(false);
            jLabel4.setVisible(false);
            Comprobante(id_venta, monto, cambio, ingreso);
        }else{
           int cambioT=0; 
           Comprobante(id_venta, monto, cambio, monto);
        }
        
        
        //se incrementa el numero de venta
        incrementaNoVenta();   
               
        //Dejando en 0 la variable para que cuando se haga la otra venta, funcione correctamente
        calculoTotal=0;
    }//GEN-LAST:event_btPagarActionPerformed

    private void jRadioButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jRadioButton2ActionPerformed
        // TODO add your handling code here:
        metodo_pago="TARJETA";
        txtIngreso.setVisible(false);
        jLabel4.setVisible(false);
    }//GEN-LAST:event_jRadioButton2ActionPerformed

    private void jRadioButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jRadioButton1ActionPerformed
        // TODO add your handling code here:
        metodo_pago="EFECTIVO";
        txtIngreso.setVisible(true);
        jLabel4.setVisible(true);
    }//GEN-LAST:event_jRadioButton1ActionPerformed

    private void CBCANTIDADPRODUCTOSActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CBCANTIDADPRODUCTOSActionPerformed
        // TODO add your handling code here:
        //AQUI, AL PRESIONAR LA CANTIDAD DE PRODUCTOS, SE DEBE LLENAR UNA TUPLA DEL JTABLE
        int cod_barras=Integer.parseInt(CBCODIGOSVENTA.getSelectedItem().toString());
        String des_producto=productos.desProducto(cod_barras);
        String precio=productos.PrecioV(cod_barras);
        
        int Subtotal=Integer.parseInt(CBCANTIDADPRODUCTOS.getSelectedItem().toString())*Integer.parseInt(precio);
        calculoTotal=Subtotal+calculoTotal;
        
        String []datos=new String[5];
        datos[0]=des_producto;
        datos[1]=CBCODIGOSVENTA.getSelectedItem().toString();
        datos[2]=precio;
        datos[3]=CBCANTIDADPRODUCTOS.getSelectedItem().toString();
        datos[4]=String.valueOf(Subtotal);
        modeloT.addRow(datos);
        //Se incrementa el total
        txt_TotalVenta.setText(calculoTotal+""); 
        CBCODIGOSVENTA.setSelectedIndex(0);
        CBCANTIDADPRODUCTOS.setSelectedIndex(0); 
    }//GEN-LAST:event_CBCANTIDADPRODUCTOSActionPerformed

    private void txt_CambioVentaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_CambioVentaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_CambioVentaActionPerformed

    private void btComprasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btComprasActionPerformed
        // TODO add your handling code here:
        Compras com=new Compras();
        com.setVisible(true);
    }//GEN-LAST:event_btComprasActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // TODO add your handling code here:
        Categorias cat=new Categorias();
        cat.setVisible(true);
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        // TODO add your handling code here:
        llenar_ComboCodigos();
    }//GEN-LAST:event_jButton2ActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        // TODO add your handling code here:
        jPanel7.setVisible(false);
    }//GEN-LAST:event_jButton3ActionPerformed

    private void jButton5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton5ActionPerformed
        // TODO add your handling code here:
        jPanel7.setVisible(true);
    }//GEN-LAST:event_jButton5ActionPerformed

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
        // TODO add your handling code here:
        jPanel2.setVisible(false);
    }//GEN-LAST:event_jButton4ActionPerformed

    
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Principal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Principal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Principal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Principal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Principal().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton BTVENTAS;
    private javax.swing.JComboBox<String> CBCANTIDADPRODUCTOS;
    private javax.swing.JComboBox<String> CBCODIGOSVENTA;
    private javax.swing.JLabel VENTA;
    private javax.swing.JButton btCompras;
    private javax.swing.JButton btPagar;
    private javax.swing.JButton bt_Productos;
    private javax.swing.ButtonGroup grupoJB;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JButton jButton5;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JRadioButton jRadioButton1;
    private javax.swing.JRadioButton jRadioButton2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JTable jTable1;
    private javax.swing.JTable jTable2;
    private javax.swing.JTable jTable3;
    private javax.swing.JTextField jTextField1;
    private javax.swing.JTextField jTextField2;
    private javax.swing.JTextField jTextField3;
    private javax.swing.JTextField jTextField4;
    private javax.swing.JLabel jlabelFecha;
    private javax.swing.JTextField txtIngreso;
    private javax.swing.JTextField txtNoVenta;
    private javax.swing.JTextField txt_CambioVenta;
    private javax.swing.JTextField txt_TotalVenta;
    // End of variables declaration//GEN-END:variables
}
