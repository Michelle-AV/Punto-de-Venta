package vista;
import basededatos.*;
import java.sql.*;
import java.time.LocalDate;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;

public class Reportes extends javax.swing.JFrame {

    Statement st;
    ResultSet rs;
    ConexionAbarrotes c;
    ProductosBD pro;
    Connection conexion;
    DefaultTableModel modelo = new DefaultTableModel();
    DefaultTableModel modelo2= new DefaultTableModel();
    LocalDate datehoy=LocalDate.now();

    public Reportes() {
        initComponents();
        this.setResizable(false);
        this.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        this.setLocationRelativeTo(null);
        c = new ConexionAbarrotes();
        pro=new ProductosBD();
        conexion = c.retornoConexion();
        llenar_ComboCodigos();
        ocultar();
        jLabel13.setVisible(false);
        TXTTOTALP.setVisible(false);
        ocultardos();
    }

    

    //METODO PARA LIMPIAR LA TABLA
    public void limpiarTabla( JTable TABLITA) {
        DefaultTableModel modelo2 = (DefaultTableModel) TABLITA.getModel();
        while (modelo2.getRowCount() > 0) {
            modelo2.removeRow(0);
        }
        String x[]={"","","","",""};
        modelo2.setColumnIdentifiers(x);
    }

    //Metodo para ocultar componentes del panel ventas
    public void ocultardos(){
        jLabel16.setVisible(false);
        jLabel17.setVisible(false);
        jLabel18.setVisible(false);
        jLabel19.setVisible(false);
        jLabel20.setVisible(false);
        jLabel21.setVisible(false);
        jLabel22.setVisible(false);
        jLabel23.setVisible(false);
        
        jcbAnio2.setVisible(false);
        jcbMes2.setVisible(false);
        jcbDia2.setVisible(false);
        jcbAnio3.setVisible(false);
        jcbMes3.setVisible(false);
        jcbDia3.setVisible(false);
    }
    
    //Ocultando componentes del panel producto
    public void ocultar() {
        jLabel8.setVisible(false);
        jLabel9.setVisible(false);
        jLabel10.setVisible(false);
        jLabel11.setVisible(false);
        jcbAnio1.setVisible(false);
        jcbMes1.setVisible(false);
        jcbDia1.setVisible(false);
    }

    //Metodo para llenar el JCombobox de codigos de barra
    public void llenar_ComboCodigos() {
        cbCodigos.removeAllItems();
        cbCodigos.addItem("CODIGOS");
        String[] codigosCB = pro.codigosB();
        for (String i : codigosCB) {
            cbCodigos.addItem(i);//Se agregan en el combobox
        }
    }

    //select compras.id_compra, compras.fecha_com, detallecompras.cod_barra, detallecompras.precio_com, detallecompras.cantidad From compras inner join detallecompras on compras.id_compra=detallecompras.id_compra where compras.fecha_com='2022-01-11' and detallecompras.cod_barra=53426798;
    //select sum(detallecompras.cantidad) From compras inner join detallecompras on compras.id_compra=detallecompras.id_compra where compras.fecha_com='2022-01-11' and detallecompras.cod_barra=53426798;
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        buttonGroup1 = new javax.swing.ButtonGroup();
        buttonGroup2 = new javax.swing.ButtonGroup();
        jPanel1 = new javax.swing.JPanel();
        jTabbedPane1 = new javax.swing.JTabbedPane();
        panelProductos = new javax.swing.JPanel();
        jLabel3 = new javax.swing.JLabel();
        jcbAnio = new javax.swing.JComboBox<>();
        jcbMes = new javax.swing.JComboBox<>();
        jcbDia = new javax.swing.JComboBox<>();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jcbAnio1 = new javax.swing.JComboBox<>();
        jLabel10 = new javax.swing.JLabel();
        jcbMes1 = new javax.swing.JComboBox<>();
        jLabel11 = new javax.swing.JLabel();
        jcbDia1 = new javax.swing.JComboBox<>();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jPanel3 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        rbDia = new javax.swing.JRadioButton();
        rbRango = new javax.swing.JRadioButton();
        cbCodigos = new javax.swing.JComboBox<>();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jLabel13 = new javax.swing.JLabel();
        TXTTOTALP = new javax.swing.JTextField();
        jLabel25 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        jLabel14 = new javax.swing.JLabel();
        rbHoy = new javax.swing.JRadioButton();
        rbEspecifico = new javax.swing.JRadioButton();
        rbRangoFecha = new javax.swing.JRadioButton();
        jScrollPane2 = new javax.swing.JScrollPane();
        jTable2 = new javax.swing.JTable();
        jPanel4 = new javax.swing.JPanel();
        TXTTOTALVENTA = new javax.swing.JTextField();
        jLabel15 = new javax.swing.JLabel();
        jButton3 = new javax.swing.JButton();
        jLabel16 = new javax.swing.JLabel();
        jLabel17 = new javax.swing.JLabel();
        jcbAnio2 = new javax.swing.JComboBox<>();
        jLabel18 = new javax.swing.JLabel();
        jcbMes2 = new javax.swing.JComboBox<>();
        jLabel19 = new javax.swing.JLabel();
        jcbDia2 = new javax.swing.JComboBox<>();
        jLabel20 = new javax.swing.JLabel();
        jLabel21 = new javax.swing.JLabel();
        jcbAnio3 = new javax.swing.JComboBox<>();
        jLabel22 = new javax.swing.JLabel();
        jcbMes3 = new javax.swing.JComboBox<>();
        jLabel23 = new javax.swing.JLabel();
        jcbDia3 = new javax.swing.JComboBox<>();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        panelProductos.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel3.setFont(new java.awt.Font("Microsoft JhengHei UI", 1, 12)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(113, 82, 82));
        jLabel3.setText("Indica la fecha:");
        panelProductos.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 210, -1, 20));

        jcbAnio.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "2020", "2021", "2022", "2023", "2024", "2025", "2026", "2027", "2028", "2029", "2030", "2031", "2032" }));
        jcbAnio.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        panelProductos.add(jcbAnio, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 210, 70, -1));

        jcbMes.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12" }));
        panelProductos.add(jcbMes, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 210, -1, -1));

        jcbDia.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30", "31" }));
        panelProductos.add(jcbDia, new org.netbeans.lib.awtextra.AbsoluteConstraints(340, 210, -1, -1));

        jLabel5.setForeground(new java.awt.Color(157, 136, 136));
        jLabel5.setText("dia");
        panelProductos.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(350, 190, -1, -1));

        jLabel6.setForeground(new java.awt.Color(157, 136, 136));
        jLabel6.setText("año");
        panelProductos.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 190, -1, -1));

        jLabel7.setForeground(new java.awt.Color(157, 136, 136));
        jLabel7.setText("mes");
        panelProductos.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 190, -1, -1));

        jLabel8.setText("hasta");
        panelProductos.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 210, 40, -1));

        jLabel9.setForeground(new java.awt.Color(133, 108, 108));
        jLabel9.setText("año");
        panelProductos.add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(530, 190, -1, -1));

        jcbAnio1.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "2020", "2021", "2022", "2023", "2024", "2025", "2026", "2027", "2028", "2029", "2030", "2031", "2032" }));
        jcbAnio1.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        panelProductos.add(jcbAnio1, new org.netbeans.lib.awtextra.AbsoluteConstraints(508, 210, 70, -1));

        jLabel10.setForeground(new java.awt.Color(133, 108, 108));
        jLabel10.setText("mes");
        panelProductos.add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(620, 190, -1, -1));

        jcbMes1.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12" }));
        panelProductos.add(jcbMes1, new org.netbeans.lib.awtextra.AbsoluteConstraints(610, 210, -1, -1));

        jLabel11.setForeground(new java.awt.Color(133, 108, 108));
        jLabel11.setText("dia");
        panelProductos.add(jLabel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(690, 190, -1, -1));

        jcbDia1.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30", "31" }));
        panelProductos.add(jcbDia1, new org.netbeans.lib.awtextra.AbsoluteConstraints(680, 210, -1, -1));

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "-", "-", "-", "-"
            }
        ));
        jScrollPane1.setViewportView(jTable1);

        panelProductos.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 270, 530, 140));

        jPanel3.setBackground(new java.awt.Color(235, 235, 235));
        jPanel3.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel2.setBackground(new java.awt.Color(101, 71, 74));
        jLabel2.setFont(new java.awt.Font("Microsoft JhengHei", 1, 12)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(88, 66, 66));
        jLabel2.setText("Elige el codigo del producto:");
        jPanel3.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 20, -1, 20));

        jLabel4.setBackground(new java.awt.Color(101, 71, 74));
        jLabel4.setFont(new java.awt.Font("Microsoft JhengHei", 1, 12)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(88, 66, 66));
        jLabel4.setText("REPORTE: ");
        jPanel3.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 60, -1, 20));

        buttonGroup1.add(rbDia);
        rbDia.setText("Dia");
        rbDia.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rbDiaActionPerformed(evt);
            }
        });
        jPanel3.add(rbDia, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 60, 60, -1));

        buttonGroup1.add(rbRango);
        rbRango.setText("Rango de fechas");
        rbRango.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rbRangoActionPerformed(evt);
            }
        });
        jPanel3.add(rbRango, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 60, 130, -1));

        cbCodigos.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        jPanel3.add(cbCodigos, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 20, 110, -1));

        panelProductos.add(jPanel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 80, 330, 100));

        jButton1.setText("REPORTE DE EGRESOS");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        panelProductos.add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(600, 450, -1, 30));

        jButton2.setText("REPORTE DE INGRESOS");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        panelProductos.add(jButton2, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 450, -1, 30));

        jLabel13.setFont(new java.awt.Font("Microsoft JhengHei UI", 1, 12)); // NOI18N
        jLabel13.setText("TOTAL DEL PRODUCTO");
        panelProductos.add(jLabel13, new org.netbeans.lib.awtextra.AbsoluteConstraints(600, 300, 140, -1));
        panelProductos.add(TXTTOTALP, new org.netbeans.lib.awtextra.AbsoluteConstraints(630, 340, 70, -1));

        jLabel25.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Iconos/Reportes.png"))); // NOI18N
        panelProductos.add(jLabel25, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, -1));

        jTabbedPane1.addTab("PRODUCTOS", panelProductos);

        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel14.setFont(new java.awt.Font("Dialog", 1, 18)); // NOI18N
        jLabel14.setForeground(new java.awt.Color(103, 85, 85));
        jLabel14.setText("REPORTE: ");
        jPanel2.add(jLabel14, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 90, -1, 20));

        buttonGroup2.add(rbHoy);
        rbHoy.setText("Diario (hoy)");
        rbHoy.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rbHoyActionPerformed(evt);
            }
        });
        jPanel2.add(rbHoy, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 90, 110, -1));

        buttonGroup2.add(rbEspecifico);
        rbEspecifico.setText("Dia especifico");
        rbEspecifico.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rbEspecificoActionPerformed(evt);
            }
        });
        jPanel2.add(rbEspecifico, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 90, 120, -1));

        buttonGroup2.add(rbRangoFecha);
        rbRangoFecha.setText("Rango de fechas");
        rbRangoFecha.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rbRangoFechaActionPerformed(evt);
            }
        });
        jPanel2.add(rbRangoFecha, new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 90, 140, -1));

        jTable2.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null}
            },
            new String [] {
                "-", "-", "-"
            }
        ));
        jScrollPane2.setViewportView(jTable2);

        jPanel2.add(jScrollPane2, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 220, -1, 190));

        jPanel4.setBackground(new java.awt.Color(229, 223, 223));
        jPanel4.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());
        jPanel4.add(TXTTOTALVENTA, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 90, 110, 30));

        jLabel15.setFont(new java.awt.Font("Microsoft JhengHei", 1, 12)); // NOI18N
        jLabel15.setForeground(new java.awt.Color(117, 100, 100));
        jLabel15.setText("TOTAL DE VENTA $");
        jPanel4.add(jLabel15, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 50, 130, 30));

        jPanel2.add(jPanel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(540, 220, 190, 190));

        jButton3.setText("GENERAR REPORTE");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });
        jPanel2.add(jButton3, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 450, 170, 30));

        jLabel16.setFont(new java.awt.Font("Microsoft JhengHei UI", 1, 12)); // NOI18N
        jLabel16.setForeground(new java.awt.Color(91, 71, 71));
        jLabel16.setText("Selecciona fecha:");
        jPanel2.add(jLabel16, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 160, -1, -1));

        jLabel17.setText("año");
        jPanel2.add(jLabel17, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 140, -1, -1));

        jcbAnio2.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "2020", "2021", "2022", "2023", "2024", "2025", "2026", "2027", "2028", "2029", "2030", "2031", "2032" }));
        jcbAnio2.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        jPanel2.add(jcbAnio2, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 160, -1, -1));

        jLabel18.setText("mes");
        jPanel2.add(jLabel18, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 140, -1, -1));

        jcbMes2.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12" }));
        jPanel2.add(jcbMes2, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 160, -1, -1));

        jLabel19.setText("dia");
        jPanel2.add(jLabel19, new org.netbeans.lib.awtextra.AbsoluteConstraints(350, 140, -1, -1));

        jcbDia2.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30", "31" }));
        jPanel2.add(jcbDia2, new org.netbeans.lib.awtextra.AbsoluteConstraints(340, 160, -1, -1));

        jLabel20.setText("hasta");
        jPanel2.add(jLabel20, new org.netbeans.lib.awtextra.AbsoluteConstraints(440, 160, 40, -1));

        jLabel21.setText("año");
        jPanel2.add(jLabel21, new org.netbeans.lib.awtextra.AbsoluteConstraints(540, 140, -1, -1));

        jcbAnio3.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "2020", "2021", "2022", "2023", "2024", "2025", "2026", "2027", "2028", "2029", "2030", "2031", "2032" }));
        jcbAnio3.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        jPanel2.add(jcbAnio3, new org.netbeans.lib.awtextra.AbsoluteConstraints(520, 160, -1, -1));

        jLabel22.setText("mes");
        jPanel2.add(jLabel22, new org.netbeans.lib.awtextra.AbsoluteConstraints(610, 140, -1, -1));

        jcbMes3.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12" }));
        jPanel2.add(jcbMes3, new org.netbeans.lib.awtextra.AbsoluteConstraints(600, 160, -1, -1));

        jLabel23.setText("dia");
        jPanel2.add(jLabel23, new org.netbeans.lib.awtextra.AbsoluteConstraints(680, 140, -1, -1));

        jcbDia3.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30", "31" }));
        jPanel2.add(jcbDia3, new org.netbeans.lib.awtextra.AbsoluteConstraints(670, 160, -1, -1));

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Iconos/ReportesvENTAS.png"))); // NOI18N
        jPanel2.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, -1));

        jTabbedPane1.addTab("VENTAS", jPanel2);

        jPanel1.add(jTabbedPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 780, 520));

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 780, 530));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // TODO add your handling code here:
        limpiarTabla(jTable1);
        String []columns={"NUM VENTA", "FECHA EGRESO", "CODIGO BARRA", "MONTO VENTA", "CANTIDAD PRODUCTO"};
        modelo.setColumnIdentifiers(columns);
        jTable1.setModel(modelo);
        
        String codigo = cbCodigos.getSelectedItem().toString();
        String fecha1 = jcbAnio.getSelectedItem().toString() + "-" + jcbMes.getSelectedItem().toString() + "-" + jcbDia.getSelectedItem().toString();
        String fecha2 = jcbAnio1.getSelectedItem().toString() + "-" + jcbMes1.getSelectedItem().toString() + "-" + jcbDia1.getSelectedItem().toString();
        
        if(rbDia.isSelected()==true){
            String sql="select ventas.id_venta, ventas.fecha_venta, detalleventas.cod_barra, detalleventas.monto, detalleventas.cantidad_v from detalleventas inner join ventas on ventas.id_venta=detalleventas.id_venta where ventas.fecha_venta='"+fecha1+"' and detalleventas.cod_barra="+codigo+";";
            try {
                st = conexion.createStatement();
                rs = st.executeQuery(sql);
                while (rs.next()) {
                    String[] datos = new String[5];
                    datos[0] = rs.getString("id_venta");
                    datos[1] = rs.getString("fecha_venta");
                    datos[2] = rs.getString("cod_barra");
                    datos[3] = rs.getString("monto");
                    datos[4] = rs.getString("cantidad_v");
                    modelo.addRow(datos);
                }
                rs = st.executeQuery("select SUM(detalleventas.cantidad_v) from detalleventas inner join ventas on ventas.id_venta=detalleventas.id_venta where ventas.fecha_venta='"+fecha1+"' and detalleventas.cod_barra="+codigo+";");
                rs.next();
                jLabel13.setVisible(true);
                TXTTOTALP.setVisible(true);
                TXTTOTALP.setText(rs.getString("sum"));
            } catch (Exception er) {
                System.out.println(er.getMessage());
            } finally {
                try {
                    st.close();
                } catch (SQLException l) {
                    JOptionPane.showMessageDialog(null, l.getMessage());
                }
            }
        
        }else if(rbRango.isSelected() == true){
            String sql="select ventas.id_venta, ventas.fecha_venta, detalleventas.cod_barra, detalleventas.monto, detalleventas.cantidad_v from detalleventas inner join ventas on ventas.id_venta=detalleventas.id_venta where ventas.fecha_venta>='"+fecha1+"' and ventas.fecha_venta<='"+fecha2+"' and detalleventas.cod_barra="+codigo+";";
            try {
                st = conexion.createStatement();
                rs = st.executeQuery(sql);
                while (rs.next()) {
                    String[] datos = new String[5];
                    datos[0] = rs.getString("id_venta");
                    datos[1] = rs.getString("fecha_venta");
                    datos[2] = rs.getString("cod_barra");
                    datos[3] = rs.getString("monto");
                    datos[4] = rs.getString("cantidad_v");
                    modelo.addRow(datos);
                }
                rs =st.executeQuery("select SUM(detalleventas.cantidad_v) from detalleventas inner join ventas on ventas.id_venta=detalleventas.id_venta where ventas.fecha_venta>='"+fecha1+"' and ventas.fecha_venta<='"+fecha2+"' and detalleventas.cod_barra="+codigo+";");
                rs.next();
                jLabel13.setVisible(true);
                TXTTOTALP.setVisible(true);
                TXTTOTALP.setText(rs.getString("sum"));
            } catch (Exception er) {
                System.out.println(er.getMessage());
            } finally {
                try {
                    st.close();
                } catch (SQLException l) {
                    JOptionPane.showMessageDialog(null, l.getMessage());
                }
            }
        
        
        }
        
        
        
    }//GEN-LAST:event_jButton1ActionPerformed

    private void rbRangoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rbRangoActionPerformed
        // TODO add your handling code here:
        jLabel8.setVisible(true);
        jLabel9.setVisible(true);
        jLabel10.setVisible(true);
        jLabel11.setVisible(true);
        jcbAnio1.setVisible(true);
        jcbMes1.setVisible(true);
        jcbDia1.setVisible(true);
        jLabel13.setVisible(false);
        TXTTOTALP.setVisible(false);
    }//GEN-LAST:event_rbRangoActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        // TODO add your handling code here:
        //si el radio button 'DIA' es seleccionado, se hace la consulta de la suma de los productos por dia
        limpiarTabla(jTable1);
        String columnas[] = {"NUM COMPRA", "FECHA INGRESO", "CODIGO BARRA", "PRECIO COMPRA", "CANTIDAD PRODUCTO"};
        modelo.setColumnIdentifiers(columnas);
        jTable1.setModel(modelo);
        String codigo = cbCodigos.getSelectedItem().toString();
        String fecha1 = jcbAnio.getSelectedItem().toString() + "-" + jcbMes.getSelectedItem().toString() + "-" + jcbDia.getSelectedItem().toString();
        String fecha2 = jcbAnio1.getSelectedItem().toString() + "-" + jcbMes1.getSelectedItem().toString() + "-" + jcbDia1.getSelectedItem().toString();

        if (rbDia.isSelected() == true) {
            String sql = "select compras.id_compra, compras.fecha_com, detallecompras.cod_barra, detallecompras.precio_com, detallecompras.cantidad From compras inner join detallecompras on compras.id_compra=detallecompras.id_compra where compras.fecha_com='" + fecha1 + "' and detallecompras.cod_barra=" + codigo + ";";
            try {
                st = conexion.createStatement();
                rs = st.executeQuery(sql);
                while (rs.next()) {
                    String[] datos = new String[5];
                    datos[0] = rs.getString("id_compra");
                    datos[1] = rs.getString("fecha_com");
                    datos[2] = rs.getString("cod_barra");
                    datos[3] = rs.getString("precio_com");
                    datos[4] = rs.getString("cantidad");
                    modelo.addRow(datos);
                }
                rs = st.executeQuery("select sum(detallecompras.cantidad) From compras inner join detallecompras on compras.id_compra=detallecompras.id_compra where compras.fecha_com='" + fecha1 + "' and detallecompras.cod_barra=" + codigo + ";");
                rs.next();
                jLabel13.setVisible(true);
                TXTTOTALP.setVisible(true);
                TXTTOTALP.setText(rs.getString("sum"));
            } catch (Exception er) {
                System.out.println(er.getMessage());
            } finally {
                try {
                    st.close();
                } catch (SQLException l) {
                    JOptionPane.showMessageDialog(null, l.getMessage());
                }
            }
        } else if (rbRango.isSelected() == true) {
            String sql = "select compras.id_compra, compras.fecha_com, detallecompras.cod_barra, detallecompras.precio_com, detallecompras.cantidad From compras inner join detallecompras on compras.id_compra=detallecompras.id_compra where compras.fecha_com>='" + fecha1 + "'and compras.fecha_com<='" + fecha2 + "' and detallecompras.cod_barra=" + codigo + ";";
            try {
                st = conexion.createStatement();
                rs = st.executeQuery(sql);
                while (rs.next()) {
                    String[] datos = new String[5];
                    datos[0] = rs.getString("id_compra");
                    datos[1] = rs.getString("fecha_com");
                    datos[2] = rs.getString("cod_barra");
                    datos[3] = rs.getString("precio_com");
                    datos[4] = rs.getString("cantidad");
                    modelo.addRow(datos);
                }
                rs = st.executeQuery("select sum( detallecompras.cantidad) From compras inner join detallecompras on compras.id_compra=detallecompras.id_compra where compras.fecha_com>='" + fecha1 + "' and compras.fecha_com<='" + fecha2 + "' and detallecompras.cod_barra=" + codigo + ";");
                rs.next();
                jLabel13.setVisible(true);
                TXTTOTALP.setVisible(true);
                TXTTOTALP.setText(rs.getString("sum"));
            } catch (Exception er) {
                System.out.println(er.getMessage());
            } finally {
                try {
                    st.close();
                } catch (SQLException l) {
                    JOptionPane.showMessageDialog(null, l.getMessage());
                }
            }
        }
    }//GEN-LAST:event_jButton2ActionPerformed

    private void rbDiaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rbDiaActionPerformed
        // TODO add your handling code here:
        ocultar();
        jLabel13.setVisible(false);
        TXTTOTALP.setVisible(false);
    }//GEN-LAST:event_rbDiaActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        // TODO add your handling code here:
        limpiarTabla( jTable2);
        String []col={"NUM VENTA","FECHA VENTA","MONTO $"};
        modelo2.setColumnIdentifiers(col);
        jTable2.setModel(modelo2);
        
        String fecha1=jcbAnio2.getSelectedItem().toString()+"-"+jcbMes2.getSelectedItem().toString()+"-"+ jcbDia2.getSelectedItem().toString();
        String fecha2=jcbAnio3.getSelectedItem().toString()+"-"+jcbMes3.getSelectedItem().toString()+"-"+ jcbDia3.getSelectedItem().toString();
        
        if(rbHoy.isSelected()==true){
            String sql="select id_venta, fecha_venta, monto from ventas where fecha_venta='"+datehoy+"';";
            try{
                st=conexion.createStatement();
                rs=st.executeQuery(sql);
                while(rs.next()){
                    String []info=new String[3];
                    info[0]=rs.getString("id_venta");
                    info[1]=rs.getString("fecha_venta");
                    info[2]=rs.getString("monto");
                    modelo2.addRow(info);
                }
                rs=st.executeQuery("select SUM(monto) from ventas where fecha_venta='"+datehoy+"';");
                rs.next();
                TXTTOTALVENTA.setText(rs.getString("sum"));
                TXTTOTALVENTA.setEditable(false);
            }catch(Exception r){
                System.out.println(r.getMessage());
            }finally{
                try{
                   st.close();
                }catch(SQLException e){
                    JOptionPane.showMessageDialog(null, e.getMessage());
                }
            } 
        }else if(rbEspecifico.isSelected()==true){
            String sql="select id_venta, fecha_venta, monto from ventas where fecha_venta='"+fecha1+"';";
            try{
                st=conexion.createStatement();
                rs=st.executeQuery(sql);
                while(rs.next()){
                    String []info=new String[3];
                    info[0]=rs.getString("id_venta");
                    info[1]=rs.getString("fecha_venta");
                    info[2]=rs.getString("monto");
                    modelo2.addRow(info);
                }
                rs=st.executeQuery("select SUM(monto) from ventas where fecha_venta='"+fecha1+"';");
                rs.next();
                TXTTOTALVENTA.setText(rs.getString("sum"));
                TXTTOTALVENTA.setEditable(false);
            }catch(Exception r){
                System.out.println(r.getMessage());
            }finally{
                try{
                   st.close();
                }catch(SQLException e){
                    JOptionPane.showMessageDialog(null, e.getMessage());
                }
            }
        }else if(rbRangoFecha.isSelected()==true){
            String sql="select id_venta, fecha_venta, monto from ventas where fecha_venta>='"+fecha1+"' and  fecha_venta<='"+fecha2+"';";
            try{
                st=conexion.createStatement();
                rs=st.executeQuery(sql);
                while(rs.next()){
                    String []info=new String[3];
                    info[0]=rs.getString("id_venta");
                    info[1]=rs.getString("fecha_venta");
                    info[2]=rs.getString("monto");
                    modelo2.addRow(info);
                }
                rs=st.executeQuery("select sum(monto) from ventas where fecha_venta>='"+fecha1+"' and  fecha_venta<='"+fecha2+"';");
                rs.next();
                TXTTOTALVENTA.setText(rs.getString("sum"));
                TXTTOTALVENTA.setEditable(false);
            }catch(Exception r){
                System.out.println(r.getMessage());
            }finally{
                try{
                   st.close();
                }catch(SQLException e){
                    JOptionPane.showMessageDialog(null, e.getMessage());
                }
            }
        }
    }//GEN-LAST:event_jButton3ActionPerformed

    private void rbHoyActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rbHoyActionPerformed
        // TODO add your handling code here:
        ocultardos();
    }//GEN-LAST:event_rbHoyActionPerformed

    private void rbEspecificoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rbEspecificoActionPerformed
        // TODO add your handling code here:
        jcbAnio2.setVisible(true);
        jcbMes2.setVisible(true);
        jcbDia2.setVisible(true);
        jcbAnio3.setVisible(false);
        jcbMes3.setVisible(false);
        jcbDia3.setVisible(false);
        
        jLabel16.setVisible(true);
        jLabel17.setVisible(true);
        jLabel18.setVisible(true);
        jLabel19.setVisible(true);
         jLabel20.setVisible(false);
        jLabel21.setVisible(false);
        jLabel22.setVisible(false);
        jLabel23.setVisible(false);
    }//GEN-LAST:event_rbEspecificoActionPerformed

    private void rbRangoFechaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rbRangoFechaActionPerformed
        // TODO add your handling code here:
        jLabel16.setVisible(true);
        jLabel17.setVisible(true);
        jLabel18.setVisible(true);
        jLabel19.setVisible(true);
        jLabel20.setVisible(true);
        jLabel21.setVisible(true);
        jLabel22.setVisible(true);
        jLabel23.setVisible(true);
        
        jcbAnio2.setVisible(true);
        jcbMes2.setVisible(true);
        jcbDia2.setVisible(true);
        jcbAnio3.setVisible(true);
        jcbMes3.setVisible(true);
        jcbDia3.setVisible(true);
    }//GEN-LAST:event_rbRangoFechaActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Reportes.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Reportes.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Reportes.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Reportes.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Reportes().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField TXTTOTALP;
    private javax.swing.JTextField TXTTOTALVENTA;
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.ButtonGroup buttonGroup2;
    private javax.swing.JComboBox<String> cbCodigos;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel23;
    private javax.swing.JLabel jLabel25;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTabbedPane jTabbedPane1;
    private javax.swing.JTable jTable1;
    private javax.swing.JTable jTable2;
    private javax.swing.JComboBox<String> jcbAnio;
    private javax.swing.JComboBox<String> jcbAnio1;
    private javax.swing.JComboBox<String> jcbAnio2;
    private javax.swing.JComboBox<String> jcbAnio3;
    private javax.swing.JComboBox<String> jcbDia;
    private javax.swing.JComboBox<String> jcbDia1;
    private javax.swing.JComboBox<String> jcbDia2;
    private javax.swing.JComboBox<String> jcbDia3;
    private javax.swing.JComboBox<String> jcbMes;
    private javax.swing.JComboBox<String> jcbMes1;
    private javax.swing.JComboBox<String> jcbMes2;
    private javax.swing.JComboBox<String> jcbMes3;
    private javax.swing.JPanel panelProductos;
    private javax.swing.JRadioButton rbDia;
    private javax.swing.JRadioButton rbEspecifico;
    private javax.swing.JRadioButton rbHoy;
    private javax.swing.JRadioButton rbRango;
    private javax.swing.JRadioButton rbRangoFecha;
    // End of variables declaration//GEN-END:variables
}
