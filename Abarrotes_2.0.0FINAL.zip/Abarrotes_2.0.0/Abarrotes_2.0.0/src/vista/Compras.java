package vista;
import basededatos.*;
import java.sql.*;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;

/* @author LGRR*/
public class Compras extends javax.swing.JFrame {
    Statement st;
    ResultSet rs;
    ComprasDB comp;
    ProductosBD produc;
    ConexionAbarrotes c;

    public Compras() {
        initComponents();
        this.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        this.setLocationRelativeTo(null);
        this.setResizable(false);
        
        c=new ConexionAbarrotes();

        
        comp=new ComprasDB();
        produc=new ProductosBD();
        llenar_ComboCodigos();
        incrementaNoCompra();
        llenar_ComboIdeCompras();
        LlenarCompras();
        LlenarDetCompras();
    }

        public void LlenarCompras(){
        ResultSet rs=c.rsMethod("Select*from compras order by id_compra;");
        DefaultTableModel modeloVenta=new DefaultTableModel();
        modeloVenta.setColumnIdentifiers(new Object[]{"Id. compra","Total","Fecha"});
        try{
            while(rs.next()){
               modeloVenta.addRow(new Object[]{rs.getString("id_compra"),rs.getString("total_com"),rs.getString("fecha_com")});
            }
            jTable1.setModel(modeloVenta);
            jTable1.setEnabled(false);//Para que no se puedan editar los datos en el componente
        }catch(Exception e){
            JOptionPane.showMessageDialog(null,e.getMessage() );
        } 
    }
        
    public void LlenarDetCompras(){
        ResultSet rs=c.rsMethod("Select*from detallecompras order by id_compra;");
        DefaultTableModel modeloVenta=new DefaultTableModel();
        modeloVenta.setColumnIdentifiers(new Object[]{"Id.Com","Codigo","Cns","Precio", "Cantidad"});
        try{
            while(rs.next()){
               modeloVenta.addRow(new Object[]{rs.getString("id_compra"),rs.getString("cod_barra"),rs.getString("cns"),rs.getString("precio_com"),rs.getString("cantidad")});
            }
            jTable2.setModel(modeloVenta);
            jTable2.setEnabled(false);//Para que no se puedan editar los datos en el componente
        }catch(Exception e){
            JOptionPane.showMessageDialog(null,e.getMessage() );
        } 
    }    
        
    public void incrementaNoCompra(){
        int id_compra=comp.numCompra();        
        txt_IdCompra.setText( Integer.toString(id_compra));
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        TabbedPane = new javax.swing.JTabbedPane();
        PanelCompra = new javax.swing.JPanel();
        txt_IdCompra = new javax.swing.JTextField();
        txtTotal_compra = new javax.swing.JTextField();
        jcbAnio = new javax.swing.JComboBox<>();
        jcbMes = new javax.swing.JComboBox<>();
        jcbDia = new javax.swing.JComboBox<>();
        btGuardarCompra = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jPanel3 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        CBCodigos = new javax.swing.JComboBox<>();
        btGuardarDETALLEcom = new javax.swing.JButton();
        txtPrecio_compra = new javax.swing.JTextField();
        txtCantidadCompra = new javax.swing.JTextField();
        CBID_COMPRA = new javax.swing.JComboBox<>();
        jScrollPane2 = new javax.swing.JScrollPane();
        jTable2 = new javax.swing.JTable();
        jLabel8 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        PanelCompra.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        txt_IdCompra.setEditable(false);
        txt_IdCompra.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        PanelCompra.add(txt_IdCompra, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 70, 60, -1));
        PanelCompra.add(txtTotal_compra, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 106, 130, -1));

        jcbAnio.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "2020", "2021", "2022", "2023", "2024", "2025", "2026", "2027", "2028", "2029", "2030", "2031", "2032" }));
        jcbAnio.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        PanelCompra.add(jcbAnio, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 140, -1, 20));

        jcbMes.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12" }));
        PanelCompra.add(jcbMes, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 140, -1, 20));

        jcbDia.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30", "31" }));
        PanelCompra.add(jcbDia, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 140, -1, 20));

        btGuardarCompra.setFont(new java.awt.Font("Microsoft JhengHei", 1, 11)); // NOI18N
        btGuardarCompra.setText("GUARDAR");
        btGuardarCompra.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btGuardarCompraActionPerformed(evt);
            }
        });
        PanelCompra.add(btGuardarCompra, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 312, 90, 30));

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3"
            }
        ));
        jScrollPane1.setViewportView(jTable1);

        PanelCompra.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 180, 380, 100));

        jPanel3.setBackground(new java.awt.Color(236, 233, 233));
        jPanel3.setForeground(new java.awt.Color(253, 248, 248));
        jPanel3.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setForeground(new java.awt.Color(104, 72, 72));
        jLabel1.setText("No. compra:");
        jPanel3.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 10, -1, -1));

        jLabel2.setForeground(new java.awt.Color(104, 72, 72));
        jLabel2.setText("Fecha:");
        jPanel3.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 70, -1, -1));

        jLabel3.setForeground(new java.awt.Color(104, 72, 72));
        jLabel3.setText("Total compra:");
        jPanel3.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 40, -1, -1));

        PanelCompra.add(jPanel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 70, 120, 90));

        jLabel10.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Iconos/ALTA DE COMPRAS.png"))); // NOI18N
        PanelCompra.add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 640, -1));

        TabbedPane.addTab("COMPRA", PanelCompra);

        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        CBCodigos.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        jPanel2.add(CBCodigos, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 110, 90, -1));

        btGuardarDETALLEcom.setText("Guardar detalle");
        btGuardarDETALLEcom.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btGuardarDETALLEcomActionPerformed(evt);
            }
        });
        jPanel2.add(btGuardarDETALLEcom, new org.netbeans.lib.awtextra.AbsoluteConstraints(500, 310, 130, 30));
        jPanel2.add(txtPrecio_compra, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 150, 90, -1));
        jPanel2.add(txtCantidadCompra, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 190, 90, -1));

        CBID_COMPRA.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        CBID_COMPRA.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CBID_COMPRAActionPerformed(evt);
            }
        });
        jPanel2.add(CBID_COMPRA, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 70, 90, -1));

        jTable2.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane2.setViewportView(jTable2);

        jPanel2.add(jScrollPane2, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 70, 320, 210));

        jLabel8.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Iconos/ALTA DE DETCOMPRAS.png"))); // NOI18N
        jPanel2.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, -1));

        TabbedPane.addTab("DETALLE COMPRA", jPanel2);

        getContentPane().add(TabbedPane, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 640, 380));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btGuardarCompraActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btGuardarCompraActionPerformed
        // TODO add your handling code here:
        int id_compra=Integer.parseInt(txt_IdCompra.getText());
        int  total_com= Integer.parseInt(txtTotal_compra.getText());
        int anio= Integer.parseInt(jcbAnio.getSelectedItem().toString());
        int mes=Integer.parseInt(jcbMes.getSelectedItem().toString());
        int dia=Integer.parseInt(jcbDia.getSelectedItem().toString());
               
        boolean resultado;
        resultado=comp.insertarCompra(id_compra, total_com, anio, mes, dia);
        if(resultado==true){
            JOptionPane.showMessageDialog(null, "Compra registrada con exito");
            txtTotal_compra.setText("");
            incrementaNoCompra();
            llenar_ComboIdeCompras();
            LlenarCompras();
        }else{
            JOptionPane.showMessageDialog(null, "No se logro guardar la compra");
        }
    }//GEN-LAST:event_btGuardarCompraActionPerformed

    private void btGuardarDETALLEcomActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btGuardarDETALLEcomActionPerformed
        // GUARDANDO DETALLE DE COMPRA:
        int id_compra=Integer.parseInt(CBID_COMPRA.getSelectedItem().toString());
        
        int cns=comp.cnsDCompra(id_compra);
        
        int cod_barra=Integer.parseInt(CBCodigos.getSelectedItem().toString());
        int precio_com=Integer.parseInt(txtPrecio_compra.getText());
        int cantidad=Integer.parseInt(txtCantidadCompra.getText());
        
        boolean resultado=comp.insertarDCompra(id_compra,cns, cod_barra, precio_com, cantidad);
        if(resultado==true && id_compra!=0){
            JOptionPane.showMessageDialog( null, "Detalle de compra registrado con exito");
            txtPrecio_compra.setText("");
            txtCantidadCompra.setText("");
            LlenarDetCompras();
        }else{
            JOptionPane.showMessageDialog(null, "Algo ocurrio mal");
        }
        
        
    }//GEN-LAST:event_btGuardarDETALLEcomActionPerformed

    private void CBID_COMPRAActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CBID_COMPRAActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_CBID_COMPRAActionPerformed
    
    //Metodo para llenar el JCombobox de codigos de barra
    public void llenar_ComboCodigos(){
        CBCodigos.removeAllItems();
        CBCodigos.addItem("CODIGOS");
        String []codigosCB=produc.codigosB();
        for(String i:codigosCB){//Por cada elemento en el arrray telefonos...(por eso se declara String i, ya que los telefonos son strings)
            CBCodigos.addItem(i);//Se agregan en el combobox
        } 
    }
   
   
    public void llenar_ComboIdeCompras(){
        CBID_COMPRA.removeAllItems();
        CBID_COMPRA.addItem("COMPRAS");
        String []comprasCB=comp.ides_compras();
        for(String i:comprasCB){//Por cada elemento en el arrray telefonos...(por eso se declara String i, ya que los telefonos son strings)
            CBID_COMPRA.addItem(i);//Se agregan en el combobox
        } 
        
        txtPrecio_compra.setText("");
        txtCantidadCompra.setText("");
        //deseleccionar los jcombobox
    }
    
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Compras.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Compras.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Compras.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Compras.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Compras().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JComboBox<String> CBCodigos;
    private javax.swing.JComboBox<String> CBID_COMPRA;
    private javax.swing.JPanel PanelCompra;
    private javax.swing.JTabbedPane TabbedPane;
    private javax.swing.JButton btGuardarCompra;
    private javax.swing.JButton btGuardarDETALLEcom;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTable jTable1;
    private javax.swing.JTable jTable2;
    private javax.swing.JComboBox<String> jcbAnio;
    private javax.swing.JComboBox<String> jcbDia;
    private javax.swing.JComboBox<String> jcbMes;
    private javax.swing.JTextField txtCantidadCompra;
    private javax.swing.JTextField txtPrecio_compra;
    private javax.swing.JTextField txtTotal_compra;
    private javax.swing.JTextField txt_IdCompra;
    // End of variables declaration//GEN-END:variables
}
