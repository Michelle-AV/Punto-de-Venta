package vista;
import basededatos.*;
import java.sql.*;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;

/* @author LGRR */
public class AltaProductos extends javax.swing.JFrame {
    Statement st;
    ResultSet rs;
    Connection conection;
    DefaultTableModel modelo=new DefaultTableModel();
    ConexionAbarrotes c;
    CategoriasBD cate;
    ProductosBD produ;
    
    
    public AltaProductos() {
        initComponents();
        this.setTitle("ABARROTES-Alta de productos");
        this.setLocationRelativeTo(null);
        this.setResizable(false);
        this.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        c=new ConexionAbarrotes();
        cate=new CategoriasBD();
        produ=new ProductosBD();
        conection=c.retornoConexion();
        llenar_ComboCategorias();
        Modelo();
        llenarTabla();
        jLabel6.setVisible(false);
        txtCodBarraE.setVisible(false);
        jButton2.setVisible(false);
        jPanel2.setVisible(false);

    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        txtCodeBarra = new javax.swing.JTextField();
        txtPrecioVenta = new javax.swing.JTextField();
        txtDes_Producto = new javax.swing.JTextField();
        CBCategorias = new javax.swing.JComboBox<>();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTablePro = new javax.swing.JTable();
        bt_GuardarProducto = new javax.swing.JButton();
        jLabel5 = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        jPanel2 = new javax.swing.JPanel();
        jLabel6 = new javax.swing.JLabel();
        txtCodBarraE = new javax.swing.JTextField();
        jButton2 = new javax.swing.JButton();
        jLabel8 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());
        jPanel1.add(txtCodeBarra, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 120, 190, -1));
        jPanel1.add(txtPrecioVenta, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 220, 190, -1));
        jPanel1.add(txtDes_Producto, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 260, 190, -1));

        CBCategorias.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        CBCategorias.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CBCategoriasActionPerformed(evt);
            }
        });
        jPanel1.add(CBCategorias, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 170, 190, -1));

        jTablePro.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane1.setViewportView(jTablePro);

        jPanel1.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 300, 740, 150));

        bt_GuardarProducto.setBackground(new java.awt.Color(255, 255, 255));
        bt_GuardarProducto.setFont(new java.awt.Font("Microsoft JhengHei", 1, 12)); // NOI18N
        bt_GuardarProducto.setForeground(new java.awt.Color(87, 64, 64));
        bt_GuardarProducto.setText("AGREGAR");
        bt_GuardarProducto.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bt_GuardarProductoActionPerformed(evt);
            }
        });
        jPanel1.add(bt_GuardarProducto, new org.netbeans.lib.awtextra.AbsoluteConstraints(780, 510, 90, 40));

        jLabel5.setText("       ALTA DE PRODUCTOS");
        jPanel1.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(340, 20, 160, -1));

        jButton1.setBackground(new java.awt.Color(255, 255, 255));
        jButton1.setFont(new java.awt.Font("Microsoft JhengHei", 1, 12)); // NOI18N
        jButton1.setForeground(new java.awt.Color(72, 45, 45));
        jButton1.setText("ELIMINAR");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 510, -1, 40));

        jPanel2.setBackground(new java.awt.Color(255, 255, 255));
        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel6.setFont(new java.awt.Font("Microsoft JhengHei", 1, 11)); // NOI18N
        jLabel6.setText("Ingresa el codigo de barras del producto a eliminar:");
        jPanel2.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 10, 280, 30));

        txtCodBarraE.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtCodBarraEActionPerformed(evt);
            }
        });
        jPanel2.add(txtCodBarraE, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 60, 210, -1));

        jButton2.setText("Eliminar producto");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        jPanel2.add(jButton2, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 110, -1, -1));

        jPanel1.add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(520, 100, 310, 170));

        jLabel8.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Iconos/Productos (1).png"))); // NOI18N
        jPanel1.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, -1));

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, 560));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void bt_GuardarProductoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bt_GuardarProductoActionPerformed
        // TODO add your handling code here:
        int cod_barra= Integer.parseInt(txtCodeBarra.getText());
        int precio_venta=Integer.parseInt(txtPrecioVenta.getText());
        String des_producto=txtDes_Producto.getText();
       
        String des_categoria=(String) CBCategorias.getSelectedItem();
        int id_cat=produ.seleccionDesCat(des_categoria);
       
        boolean res= produ.insertarProducto(cod_barra, precio_venta, des_producto, id_cat);
       
        if(id_cat==0||des_categoria=="CATEGORIAS"||res==false){
            JOptionPane.showMessageDialog(null, "No se logro guardar el producto, intenta de nuevo");
        }else{
           JOptionPane.showMessageDialog(null, "PRODUCTO GUARDADO CON EXITO");
           llenarTabla();
           
           //Procedemos a limpiar los campos
           txtCodeBarra.setText(""); txtPrecioVenta.setText(""); txtDes_Producto.setText("");
           CBCategorias.setSelectedIndex(0);     
        }
       
    }//GEN-LAST:event_bt_GuardarProductoActionPerformed

    //Metodo para crear el modelo de la tabla
    public void Modelo(){
        String columnas[]={"Categoria", "Codigo_de_barras","Precio_venta", "Descripcion"};
        modelo.setColumnIdentifiers(columnas);
        jTablePro.setModel(modelo);
    }
    
    public void limpiarTabla(){
        DefaultTableModel modelo2 = (DefaultTableModel) jTablePro.getModel();
        while(modelo2.getRowCount()>0){
            modelo2.removeRow(0);
        }
    }
   
    public void llenarTabla(){
        String sql="select categorias.des_cat, productos.cod_barra, productos.precio_venta, productos.des_producto from productos INNER JOIN categorias ON productos.id_cat=categorias.id_cat;";
        String []data=new String[4];
        limpiarTabla();
        try{
            st=conection.createStatement();
            rs=st.executeQuery(sql);
            while(rs.next()){
                data[0]=rs.getString("des_cat");
                data[1]=rs.getString("cod_barra");
                data[2]=rs.getString("precio_venta");
                data[3]=rs.getString("des_producto");
                modelo.addRow(data);
            }
        }catch(Exception e){
            System.out.println(e.getMessage());
        }finally{
            try{
                st.close();
            }catch(SQLException ex){
                System.out.println(ex.getMessage());
            }
        }
    }
   
    
    private void CBCategoriasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CBCategoriasActionPerformed
        // TODO add your handling code here:  
    }//GEN-LAST:event_CBCategoriasActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // TODO add your handling code here
        jLabel6.setVisible(true);
        txtCodBarraE.setVisible(true);
        jButton2.setVisible(true);
        jPanel2.setVisible(true);
        
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        // TODO add your handling code here:
        String cod_barra=txtCodBarraE.getText();
        
        int ress=produ.eliminarProducto(cod_barra);
         
        if(ress==1){
            JOptionPane.showMessageDialog(null, "PRODUCTO ELIMINADO CON EXITO");
        }else{
            JOptionPane.showMessageDialog(null, "Ocurrio un error, intenta de nuevo");
        }
        
        
        llenarTabla();
        jLabel6.setVisible(false);
        txtCodBarraE.setVisible(false);
        txtCodBarraE.setText("");
        jButton2.setVisible(false);
        jPanel2.setVisible(false);
        
    }//GEN-LAST:event_jButton2ActionPerformed

    private void txtCodBarraEActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtCodBarraEActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtCodBarraEActionPerformed

    //Metodo para llenar el JCombobox 
    public void llenar_ComboCategorias(){
        CBCategorias.removeAllItems();
        CBCategorias.addItem("CATEGORIAS");
        String []categoriasCB=cate.categorias();
        for(String i:categoriasCB){
            CBCategorias.addItem(i);
        } 
        txtCodeBarra.setText("");
        txtPrecioVenta.setText("");
        txtDes_Producto.setText("");
    }
    
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(AltaProductos.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(AltaProductos.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(AltaProductos.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(AltaProductos.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new AltaProductos().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JComboBox<String> CBCategorias;
    private javax.swing.JButton bt_GuardarProducto;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTablePro;
    private javax.swing.JTextField txtCodBarraE;
    private javax.swing.JTextField txtCodeBarra;
    private javax.swing.JTextField txtDes_Producto;
    private javax.swing.JTextField txtPrecioVenta;
    // End of variables declaration//GEN-END:variables
}
